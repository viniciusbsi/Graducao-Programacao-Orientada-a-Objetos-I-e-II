/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package apparray;

import java.util.Scanner;

/**
 *
 * @author vinicius
 */
public class appArrayTest {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        int valorDigitado;
        AppArray appArray = new AppArray();
        System.out.print("Valor que consta na posição '6' do array f: ");
        appArray.a();
        
        System.out.print("Array 'g' inicializado tendo '8' como o valor de todos os elementos: ");
        appArray.b();
        
        System.out.println();
        
        System.out.print("Array 'c' com 100 elementos: ");
        appArray.c();
        
        System.out.println();
        
        System.out.print("Cópia de 'a' para 'b': ");
        appArray.d();
        
        System.out.println();
        
        int[] array = new int[9];
        for(int i=0; i < 9; i++){
            System.out.print("Digite o valor a ser inserido no array:");
            array[i] = input.nextInt();    
        }
        System.out.print("Mostrar maior e menor valor que consta no array: ");
        appArray.e(array);
        
    }
    
}
