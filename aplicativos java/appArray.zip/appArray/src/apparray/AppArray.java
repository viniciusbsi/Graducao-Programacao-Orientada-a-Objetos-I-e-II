/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package apparray;
import java.util.Scanner;

/**
 *
 * @author vinicius de oliveira BSI3
 */
public class AppArray {

    /**
     * @param args the command line arguments
     */
    public void a(){
        Scanner input = new Scanner(System.in);
        int[] f = {5, 7, 4, 3, 5, 6, 9};
        System.out.println(f[6]);
    }

    public void b(){
        Scanner input = new Scanner(System.in);
        int[] g = new int[5];
        for(int i = 0; i < g.length; i++){
            
            System.out.print(g[i]);
        }    
    }
    
    public void c(){
        Scanner input = new Scanner(System.in);
        float[] c = new float[100];
        float total = 0;
        for(int i = 0; i < c.length; i++){
            c[i] = i;
            total = c[i] + total;
        }
        System.out.print(total);
        
    }
    
    public void d(){
        Scanner input = new Scanner(System.in);
        int[] a = {1,2,3,4,5,6,7,8,9,10,11};
        int[] b = new int[34];
        for(int i=0; i < 11; i++){
            b[i] = a[i];
        }
        for(int i=0; i < b.length; i++){
            System.out.print(b[i] + ", ");
        }
    }
    public void e(int[] array){
        Scanner input = new Scanner(System.in);
        int maior;
        int menor;
        maior = array[0];
        menor = array[8];
        for(int i=0; i < array.length; i++){
            if(array[i] > maior){
                maior = array[i];
            }
            if(array[i] < menor){
                menor = array[i];
            }
        }
        System.out.println();
        System.out.printf("Maior: %s", maior);
        System.out.println();
        System.out.printf("Menor: %s", menor);
    }

    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
